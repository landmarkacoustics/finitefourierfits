library(testthat)
library(finitefourierfits)

test_check("finitefourierfits")
