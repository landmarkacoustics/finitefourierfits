## Copyright (C) 2020 by Landmark Acoustics LLC

#' Fit a small, Fourier basis-like model to data
#'
#' When a functional-looking relation is poorly approximated by the tools `lm`,
#' `glm`, or `nls`, one option is to use a linear combination of cosine terms
#' to approximate the relation within a strictly bounded domain. This function
#' does just that.
#'
#' @param x Numeric, the independent variable
#' @param y Numeric, the dependent variable
#' @param model.selector Function, optional, the function for comparing models
#' @param max.terms Integer, optional, the greatest number of terms allowed
#' @return an FFFit model
#' @examples
#' x <- rnorm(10)
#' y <- 10*x + rnorm(10)
#' my.fit <- ff.fit(x, y)
#' @export
#' @importFrom stats BIC fft nextn nls
ff.fit <- function(x, y, model.selector=BIC, max.terms=10) {

    N <- length(x)
    if (length(y) != N) {
        stop("`x` and `y` must be the same length.")
    }

    fft.size <- 4*nextn(N, 2)

    u <- .domain.shift(fft.size, x)

    S <- fft(c(y, rep(0, fft.size - N)))

    a <- .amplitudes(S)
    p <- .phases(S)

    magnitude.order <- order(a, decreasing=TRUE)[1:max.terms]

    lhs <- .somehow.get.the.name.of.y(y)

    term.list <- build.term.list(magnitude.order, p)
    start.list <- as.list(a[magnitude.order])
    names(start.list) <- names(term.list)

    result <- list()
    for (i in 1:max.terms) {
        tmp <- tryCatch(nls(.build.formula(lhs, term.list[1:i]),
                            start=start.list),
                        error=.null.on.error)
        if (!is.null(tmp)) {
            result <- append(result, list(tmp))
        }
    }
    return(list(terms=term.list,
                amplitudes=a,
                phases=p,
                models=result))
}


#' A formula that describes a Finite Fourier Fit
#'
#' See \code{\link{build.term}} for the details of how each term is built.
#'
#' @param response A string or expression that will be the lhs of the formula.
#' @param term.list The terms for the rhs of the formula.
#' @return a formula that represents a Finite Fourier Basis.
#' @importFrom stats as.formula
.build.formula <- function(response, term.list) {
    return(as.formula(paste(response,
                            "~",
                            paste(term.list, collapse=" + "))))
}


.build.starts <- function(term.order, term.var, variable.name="a") {
    n <- paste(variable.name, term.order, sep="")
    v <- as.list(term.var[term.order])
    names(v) <- n
    return(v)
}

#' @importFrom stats BIC
.best.fit <- function(fit.list) {
    v <- sapply(fit.list, BIC)
    i <- argmin(v)
    return(c(index=i, BIC=v[i]))
}
