## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(finitefourierfits)

## ----eval=FALSE---------------------------------------------------------------
#  my.linters <- lintr::with_defaults(
#    object_name_linter=lintr::object_name_linter(styles="dotted.case"),
#    infix_spaces_linter=NULL,
#    commented_code_linter=NULL
#  )
#  lintr::lint_package(linters=my.linters)

## ----eval=FALSE---------------------------------------------------------------
#  my.fit <- ff.fit(my.data$x, my.data$y, model.selector=BIC)
#  my.fit$n.terms
#  coef(my.fit)

